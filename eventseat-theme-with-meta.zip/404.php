<?php
/**
 * 404 Template
 *
 * @package EventSeat
 */

get_header();
?>

<section class="page-header" style="padding: 5rem 0;">
    <div class="container" style="text-align: center;">
        <h1 class="page-title" style="font-size: 6rem; color: var(--primary-600);">404</h1>
        <p class="page-subtitle"><?php _e('Sayfa bulunamadı', 'eventseat'); ?></p>
    </div>
</section>

<section style="padding: 3rem 0;">
    <div class="container" style="text-align: center; max-width: 32rem;">
        <p style="color: var(--slate-600); margin-bottom: 2rem;">
            <?php _e('Aradığınız sayfa taşınmış, silinmiş veya hiç var olmamış olabilir.', 'eventseat'); ?>
        </p>
        
        <div class="search-box" style="margin-bottom: 2rem;">
            <form role="search" method="get" action="<?php echo esc_url(home_url('/')); ?>">
                <div class="search-input-wrapper">
                    <svg class="search-icon" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                    <input 
                        type="search" 
                        name="s" 
                        class="search-input" 
                        placeholder="<?php esc_attr_e('Ara...', 'eventseat'); ?>"
                    >
                </div>
            </form>
        </div>
        
        <a href="<?php echo esc_url(home_url('/')); ?>" class="btn btn-primary btn-lg">
            <?php _e('Ana Sayfaya Dön', 'eventseat'); ?>
        </a>
    </div>
</section>

<?php
get_footer();
