<?php
/**
 * Search results template
 *
 * @package EventSeat
 */

get_header();
?>

<section class="page-header bg-slate-50">
    <div class="container">
        <h1 class="page-title">
            <?php
            printf(
                __('"%s" için arama sonuçları', 'eventseat'),
                '<span style="color: var(--primary-600);">' . esc_html(get_search_query()) . '</span>'
            );
            ?>
        </h1>
        <p class="page-subtitle">
            <?php
            global $wp_query;
            printf(
                _n('%d sonuç bulundu', '%d sonuç bulundu', $wp_query->found_posts, 'eventseat'),
                $wp_query->found_posts
            );
            ?>
        </p>
    </div>
</section>

<section class="py-10">
    <div class="container">
        <?php if (have_posts()) : ?>
            
            <div class="events-grid">
                <?php
                while (have_posts()) :
                    the_post();
                    ?>
                    <article <?php post_class('card'); ?>>
                        <a href="<?php the_permalink(); ?>">
                            <div class="card-image">
                                <?php if (has_post_thumbnail()) : ?>
                                    <?php the_post_thumbnail('event-card'); ?>
                                <?php else : ?>
                                    <div style="display: flex; align-items: center; justify-content: center; height: 100%; color: var(--primary-400);">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </a>
                        
                        <div class="card-content">
                            <?php eventseat_category_badge(); ?>
                            
                            <h2 class="card-title">
                                <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                            </h2>
                            
                            <p style="color: var(--slate-600); font-size: 0.875rem; margin-bottom: 1rem;">
                                <?php echo wp_trim_words(get_the_excerpt(), 15, '...'); ?>
                            </p>
                            
                            <?php eventseat_event_meta(); ?>
                        </div>
                    </article>
                <?php endwhile; ?>
            </div>
            
            <!-- Pagination -->
            <?php if (get_previous_posts_link() || get_next_posts_link()) : ?>
                <nav class="pagination" aria-label="<?php esc_attr_e('Sayfalama', 'eventseat'); ?>">
                    <?php
                    echo paginate_links(array(
                        'prev_text' => '← ' . __('Önceki', 'eventseat'),
                        'next_text' => __('Sonraki', 'eventseat') . ' →',
                    ));
                    ?>
                </nav>
            <?php endif; ?>
            
        <?php else : ?>
            
            <div class="text-center py-12">
                <p class="text-slate-600 text-lg mb-4">
                    <?php _e('Aramanıza uygun sonuç bulunamadı.', 'eventseat'); ?>
                </p>
                
                <div class="search-box" style="max-width: 28rem; margin: 0 auto 2rem;">
                    <form role="search" method="get" action="<?php echo esc_url(home_url('/')); ?>">
                        <div class="search-input-wrapper">
                            <svg class="search-icon" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                            <input 
                                type="search" 
                                name="s" 
                                class="search-input" 
                                placeholder="<?php esc_attr_e('Yeni arama...', 'eventseat'); ?>"
                                value="<?php echo get_search_query(); ?>"
                            >
                        </div>
                    </form>
                </div>
                
                <a href="<?php echo esc_url(home_url('/')); ?>" class="btn btn-primary">
                    <?php _e('Tüm Etkinlikler', 'eventseat'); ?>
                </a>
            </div>
            
        <?php endif; ?>
    </div>
</section>

<?php
get_footer();
