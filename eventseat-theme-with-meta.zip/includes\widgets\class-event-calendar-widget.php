<?php
/**
 * Event Calendar Widget
 *
 * @package EventSeat
 */

if (!defined('ABSPATH')) {
    exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

class EventSeat_Elementor_Event_Calendar_Widget extends Widget_Base {
    
    public function get_name() {
        return 'eventseat_event_calendar';
    }
    
    public function get_title() {
        return __('Etkinlik Takvimi', 'eventseat');
    }
    
    public function get_icon() {
        return 'eicon-calendar';
    }
    
    public function get_categories() {
        return ['eventseat', 'general'];
    }
    
    public function get_keywords() {
        return ['calendar', 'takvim', 'event', 'etkinlik', 'date', 'tarih'];
    }
    
    protected function register_controls() {
        // Content Section
        $this->start_controls_section(
            'content_section',
            [
                'label' => __('İçerik', 'eventseat'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        
        $this->add_control(
            'title',
            [
                'label' => __('Başlık', 'eventseat'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Etkinlik Takvimi', 'eventseat'),
            ]
        );
        
        $this->add_control(
            'events_per_month',
            [
                'label' => __('Aylık Etkinlik Sayısı', 'eventseat'),
                'type' => Controls_Manager::NUMBER,
                'default' => 10,
                'min' => 1,
                'max' => 50,
            ]
        );
        
        $this->add_control(
            'show_months',
            [
                'label' => __('Gösterilecek Ay', 'eventseat'),
                'type' => Controls_Manager::NUMBER,
                'default' => 3,
                'min' => 1,
                'max' => 12,
            ]
        );
        
        $this->end_controls_section();
        
        // Style Section
        $this->start_controls_section(
            'style_section',
            [
                'label' => __('Stil', 'eventseat'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        
        $this->add_control(
            'month_header_bg',
            [
                'label' => __('Ay Başlık Arka Plan', 'eventseat'),
                'type' => Controls_Manager::COLOR,
                'default' => '#2563eb',
                'selectors' => [
                    '{{WRAPPER}} .eventseat-calendar-month-header' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_control(
            'event_item_bg',
            [
                'label' => __('Etkinlik Arka Plan', 'eventseat'),
                'type' => Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .eventseat-calendar-event' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        
        $this->end_controls_section();
    }
    
    protected function render() {
        $settings = $this->get_settings_for_display();
        
        // Get posts with event_date meta
        $args = [
            'posts_per_page' => $settings['events_per_month'] * $settings['show_months'],
            'post_type' => 'post',
            'post_status' => 'publish',
            'meta_key' => 'event_date',
            'orderby' => 'meta_value',
            'order' => 'ASC',
            'meta_query' => [
                [
                    'key' => 'event_date',
                    'value' => '',
                    'compare' => '!=',
                ],
            ],
        ];
        
        $query = new WP_Query($args);
        
        if (!$query->have_posts()) {
            echo '<p>' . __('Yaklaşan etkinlik bulunmuyor.', 'eventseat') . '</p>';
            return;
        }
        
        $months = [];
        
        while ($query->have_posts()) {
            $query->the_post();
            $date = get_post_meta(get_the_ID(), 'event_date', true);
            $time = get_post_meta(get_the_ID(), 'event_time', true);
            $location = get_post_meta(get_the_ID(), 'event_location', true);
            $venue = get_post_meta(get_the_ID(), 'event_venue', true);
            
            // Parse date to get month
            $timestamp = strtotime($date);
            if (!$timestamp) continue;
            
            $month_key = date('Y-m', $timestamp);
            $month_label = date_i18n('F Y', $timestamp);
            $day = date('j', $timestamp);
            $weekday = date_i18n('D', $timestamp);
            
            if (!isset($months[$month_key])) {
                $months[$month_key] = [
                    'label' => $month_label,
                    'events' => [],
                ];
            }
            
            $months[$month_key]['events'][] = [
                'id' => get_the_ID(),
                'title' => get_the_title(),
                'link' => get_permalink(),
                'day' => $day,
                'weekday' => $weekday,
                'time' => $time,
                'location' => $location,
                'venue' => $venue,
                'thumbnail' => get_the_post_thumbnail_url(get_the_ID(), 'thumbnail'),
            ];
        }
        
        wp_reset_postdata();
        
        // Limit months
        $months = array_slice($months, 0, $settings['show_months'], true);
        ?>
        
        <div class="eventseat-calendar-wrapper">
            <?php if (!empty($settings['title'])) : ?>
                <h3 class="eventseat-calendar-title"><?php echo esc_html($settings['title']); ?></h3>
            <?php endif; ?>
            
            <div class="eventseat-calendar">
                <?php foreach ($months as $month) : ?>
                    <div class="eventseat-calendar-month">
                        <div class="eventseat-calendar-month-header">
                            <?php echo esc_html($month['label']); ?>
                        </div>
                        <div class="eventseat-calendar-events">
                            <?php foreach ($month['events'] as $event) : ?>
                                <a href="<?php echo esc_url($event['link']); ?>" class="eventseat-calendar-event">
                                    <div class="eventseat-calendar-date">
                                        <span class="eventseat-calendar-day"><?php echo esc_html($event['day']); ?></span>
                                        <span class="eventseat-calendar-weekday"><?php echo esc_html($event['weekday']); ?></span>
                                    </div>
                                    <div class="eventseat-calendar-info">
                                        <h4 class="eventseat-calendar-event-title"><?php echo esc_html($event['title']); ?></h4>
                                        <?php if ($event['time'] || $event['venue']) : ?>
                                            <div class="eventseat-calendar-meta">
                                                <?php if ($event['time']) : ?>
                                                    <span><?php echo esc_html($event['time']); ?></span>
                                                <?php endif; ?>
                                                <?php if ($event['venue']) : ?>
                                                    <span><?php echo esc_html($event['venue']); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </a>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        
        <?php
    }
}
