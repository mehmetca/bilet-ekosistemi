# EventSeat WordPress Teması

EventSeat bilet ekosistemi projesinin WordPress teması. Modern, responsive ve etkinlik odaklı tasarım.

## Özellikler

- ✅ Responsive tasarım (mobil uyumlu)
- ✅ Modern UI (EventSeat ile aynı renk şeması)
- ✅ Özel etkinlik meta alanları (tarih, saat, yer, fiyat)
- ✅ Customizer desteği (tema ayarları)
- ✅ Widget alanları
- ✅ SEO dostu yapı
- ✅ Hızlı performans

## Kurulum

1. `eventseat-wp-theme` klasörünü WordPress `wp-content/themes/` dizinine kopyalayın
2. WordPress Admin > Görünüm > Temalar bölümüne gidin
3. "EventSeat" temasını etkinleştirin

## Renk Şeması

- **Primary (Mavi)**: #2563eb
- **Slate (Gri)**: #64748b, #334155
- **Background**: #f8fafc
- **Card**: #ffffff

## Kullanım

### Etkinlik Ekleme

Yazı düzenleyicide aşağıdaki özel alanları kullanabilirsiniz:

- `event_date` - Etkinlik tarihi (örn: 14 Mart 2026)
- `event_time` - Saat (örn: 20:00)
- `event_location` - Şehir (örn: İstanbul)
- `event_venue` - Mekan (örn: Zorlu PSM)
- `event_price` - Fiyat (örn: 350 ₺'den başlayan fiyatlarla)
- `event_buy_url` - Bilet satın alma linki

### Customizer Ayarları

WordPress Admin > Görünüm > Özelleştir bölümünden:

- Logo metni değiştirme
- Hero başlık ve alt başlık düzenleme

## Dosya Yapısı

```
eventseat-wp-theme/
├── style.css          # Tema bilgileri ve CSS
├── functions.php      # Tema fonksiyonları
├── index.php          # Ana sayfa / Blog listesi
├── single.php         # Tekil yazı / Etkinlik detay
├── page.php           # Sayfa şablonu
├── header.php         # Header şablonu
├── footer.php         # Footer şablonu
├── sidebar.php        # Sidebar şablonu
└── js/
    └── eventseat.js   # Tema JavaScript
```

## Geliştirici Notları

Bu tema EventSeat Next.js projesinin tasarımını WordPress'e taşır. CSS değişkenleri kullanarak tutarlı bir tasarım sağlar.

## Lisans

GPL-2.0-or-later
