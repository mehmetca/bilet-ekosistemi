<?php
/**
 * Template Name: Elementor Canvas (Tam Sayfa)
 * Description: Elementor için boş şablon - header/footer yok
 *
 * @package EventSeat
 */

?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <?php wp_head(); ?>
</head>
<body <?php body_class('eventseat-canvas'); ?>>
<?php wp_body_open(); ?>

<main id="main-content" class="eventseat-elementor-canvas">
    <?php
    while (have_posts()) :
        the_post();
        the_content();
    endwhile;
    ?>
</main>

<?php wp_footer(); ?>
</body>
</html>
