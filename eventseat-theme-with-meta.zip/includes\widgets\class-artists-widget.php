<?php
/**
 * Artists Widget
 *
 * @package EventSeat
 */

if (!defined('ABSPATH')) {
    exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

class EventSeat_Elementor_Artists_Widget extends Widget_Base {
    
    public function get_name() {
        return 'eventseat_artists';
    }
    
    public function get_title() {
        return __('Sanatçılar', 'eventseat');
    }
    
    public function get_icon() {
        return 'eicon-person';
    }
    
    public function get_categories() {
        return ['eventseat', 'general'];
    }
    
    public function get_keywords() {
        return ['artist', 'sanatçı', 'performer', 'müzisyen'];
    }
    
    protected function register_controls() {
        // Content Section
        $this->start_controls_section(
            'content_section',
            [
                'label' => __('İçerik', 'eventseat'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        
        $this->add_control(
            'title',
            [
                'label' => __('Başlık', 'eventseat'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Sanatçılar', 'eventseat'),
            ]
        );
        
        $this->add_control(
            'artist_tag',
            [
                'label' => __('Sanatçı Etiketi', 'eventseat'),
                'type' => Controls_Manager::TEXT,
                'default' => 'sanatci',
                'description' => __('Sanatçıları ayırt etmek için kullanılan etiket (tag)', 'eventseat'),
            ]
        );
        
        $this->add_control(
            'posts_per_page',
            [
                'label' => __('Sanatçı Sayısı', 'eventseat'),
                'type' => Controls_Manager::NUMBER,
                'default' => 12,
                'min' => 1,
                'max' => 50,
            ]
        );
        
        $this->add_control(
            'columns',
            [
                'label' => __('Kolon Sayısı', 'eventseat'),
                'type' => Controls_Manager::SELECT,
                'default' => '4',
                'options' => [
                    '2' => '2',
                    '3' => '3',
                    '4' => '4',
                    '5' => '5',
                    '6' => '6',
                ],
            ]
        );
        
        $this->add_control(
            'show_letter_filter',
            [
                'label' => __('Harf Filtresi Göster', 'eventseat'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
            ]
        );
        
        $this->end_controls_section();
        
        // Style Section
        $this->start_controls_section(
            'style_section',
            [
                'label' => __('Stil', 'eventseat'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        
        $this->add_control(
            'card_bg',
            [
                'label' => __('Kart Arka Plan', 'eventseat'),
                'type' => Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .eventseat-artist-card' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_control(
            'name_color',
            [
                'label' => __('İsim Rengi', 'eventseat'),
                'type' => Controls_Manager::COLOR,
                'default' => '#0f172a',
                'selectors' => [
                    '{{WRAPPER}} .eventseat-artist-name' => 'color: {{VALUE}};',
                ],
            ]
        );
        
        $this->end_controls_section();
    }
    
    protected function render() {
        $settings = $this->get_settings_for_display();
        
        // Get posts with artist tag
        $args = [
            'posts_per_page' => $settings['posts_per_page'],
            'post_type' => 'post',
            'post_status' => 'publish',
            'tag' => $settings['artist_tag'],
        ];
        
        $query = new WP_Query($args);
        
        if (!$query->have_posts()) {
            echo '<p>' . __('Sanatçı bulunamadı.', 'eventseat') . '</p>';
            return;
        }
        
        $artists = [];
        
        while ($query->have_posts()) {
            $query->the_post();
            $title = get_the_title();
            $first_letter = strtoupper(mb_substr($title, 0, 1));
            
            if (!isset($artists[$first_letter])) {
                $artists[$first_letter] = [];
            }
            
            $artists[$first_letter][] = [
                'id' => get_the_ID(),
                'title' => $title,
                'link' => get_permalink(),
                'thumbnail' => get_the_post_thumbnail_url(get_the_ID(), 'medium'),
            ];
        }
        
        wp_reset_postdata();
        
        ksort($artists);
        $letters = array_keys($artists);
        ?>
        
        <div class="eventseat-artists-wrapper">
            <?php if (!empty($settings['title'])) : ?>
                <h3 class="eventseat-artists-title"><?php echo esc_html($settings['title']); ?></h3>
            <?php endif; ?>
            
            <?php if ($settings['show_letter_filter'] === 'yes' && !empty($letters)) : ?>
                <div class="eventseat-artists-filter">
                    <button type="button" class="eventseat-filter-btn active" data-letter="all"><?php _e('Tümü', 'eventseat'); ?></button>
                    <?php foreach ($letters as $letter) : ?>
                        <button type="button" class="eventseat-filter-btn" data-letter="<?php echo esc_attr($letter); ?>"><?php echo esc_html($letter); ?></button>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            
            <div class="eventseat-artists-grid eventseat-grid-<?php echo esc_attr($settings['columns']); ?>">
                <?php foreach ($artists as $letter => $artist_list) : ?>
                    <?php foreach ($artist_list as $artist) : ?>
                        <div class="eventseat-artist-card" data-letter="<?php echo esc_attr($letter); ?>">
                            <a href="<?php echo esc_url($artist['link']); ?>" class="eventseat-artist-link">
                                <?php if ($artist['thumbnail']) : ?>
                                    <div class="eventseat-artist-image">
                                        <img src="<?php echo esc_url($artist['thumbnail']); ?>" alt="<?php echo esc_attr($artist['title']); ?>">
                                    </div>
                                <?php else : ?>
                                    <div class="eventseat-artist-image eventseat-artist-placeholder">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                                    </div>
                                <?php endif; ?>
                                <h4 class="eventseat-artist-name"><?php echo esc_html($artist['title']); ?></h4>
                            </a>
                        </div>
                    <?php endforeach; ?>
                <?php endforeach; ?>
            </div>
        </div>
        
        <?php
    }
}
