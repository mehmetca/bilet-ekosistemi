<?php
/**
 * EventSeat Theme Functions
 *
 * @package EventSeat
 */

// Theme version for cache busting
define('EVENTSEAT_VERSION', '1.0.0');

/**
 * Theme setup
 */
function eventseat_setup() {
    // Add theme support
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption'));
    add_theme_support('responsive-embeds');
    add_theme_support('align-wide');
    add_theme_support('customize-selective-refresh-widgets');
    
    // Add custom fields support to posts
    add_post_type_support('post', 'custom-fields');
    add_post_type_support('page', 'custom-fields');
    
    // Set thumbnail sizes
    set_post_thumbnail_size(400, 225, true);
    add_image_size('event-card', 400, 225, true);
    add_image_size('event-hero', 1200, 400, true);
    
    // Register navigation menus
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'eventseat'),
        'footer'  => __('Footer Menu', 'eventseat'),
    ));
    
    // Load text domain
    load_theme_textdomain('eventseat', get_template_directory() . '/languages');
}
add_action('after_setup_theme', 'eventseat_setup');

/**
 * Enqueue scripts and styles
 */
function eventseat_scripts() {
    // Google Fonts - Inter
    wp_enqueue_style(
        'eventseat-fonts',
        'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap',
        array(),
        null
    );
    
    // Theme stylesheet
    wp_enqueue_style(
        'eventseat-style',
        get_stylesheet_uri(),
        array('eventseat-fonts'),
        EVENTSEAT_VERSION
    );
    
    // Theme JS
    wp_enqueue_script(
        'eventseat-script',
        get_template_directory_uri() . '/js/eventseat.js',
        array(),
        EVENTSEAT_VERSION,
        true
    );
}
add_action('wp_enqueue_scripts', 'eventseat_scripts');

/**
 * Custom template tags
 */

// Event meta (date, location)
function eventseat_event_meta() {
    $date = get_post_meta(get_the_ID(), 'event_date', true);
    $time = get_post_meta(get_the_ID(), 'event_time', true);
    $location = get_post_meta(get_the_ID(), 'event_location', true);
    $venue = get_post_meta(get_the_ID(), 'event_venue', true);
    $price = get_post_meta(get_the_ID(), 'event_price', true);
    ?>
    <div class="card-meta">
        <?php if ($date) : ?>
            <span class="card-meta-item">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
                <?php echo esc_html($date); ?><?php if ($time) echo ' • ' . esc_html($time); ?>
            </span>
        <?php endif; ?>
        <?php if ($venue || $location) : ?>
            <span class="card-meta-item">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
                <?php echo esc_html($venue ? $venue . ', ' . $location : $location); ?>
            </span>
        <?php endif; ?>
    </div>
    <?php if ($price) : ?>
        <div class="card-footer">
            <span class="card-price"><?php echo esc_html($price); ?></span>
            <a href="<?php the_permalink(); ?>" class="btn btn-primary"><?php _e('Satın Al', 'eventseat'); ?></a>
        </div>
    <?php endif;
}

// Event category badge
function eventseat_category_badge() {
    $categories = get_the_category();
    if (!empty($categories)) {
        $category = $categories[0];
        printf(
            '<span class="text-primary font-medium text-sm">%s</span>',
            esc_html($category->name)
        );
    }
}

/**
 * Customizer settings
 */
function eventseat_customize_register($wp_customize) {
    // Theme Options Panel
    $wp_customize->add_panel('eventseat_options', array(
        'title'    => __('EventSeat Ayarları', 'eventseat'),
        'priority' => 30,
    ));
    
    // Header Section
    $wp_customize->add_section('eventseat_header', array(
        'title' => __('Header', 'eventseat'),
        'panel' => 'eventseat_options',
    ));
    
    $wp_customize->add_setting('eventseat_logo_text', array(
        'default' => 'EventSeat',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('eventseat_logo_text', array(
        'label'   => __('Logo Metni', 'eventseat'),
        'section' => 'eventseat_header',
        'type'    => 'text',
    ));
    
    // Hero Section
    $wp_customize->add_section('eventseat_hero', array(
        'title' => __('Hero Bölümü', 'eventseat'),
        'panel' => 'eventseat_options',
    ));
    
    $wp_customize->add_setting('eventseat_hero_title', array(
        'default' => __('Etkinlikleri Keşfedin', 'eventseat'),
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('eventseat_hero_title', array(
        'label'   => __('Başlık', 'eventseat'),
        'section' => 'eventseat_hero',
        'type'    => 'text',
    ));
    
    $wp_customize->add_setting('eventseat_hero_subtitle', array(
        'default' => __('Favori sanatçılarınızın ve etkinliklerin biletlerini kolayca bulun.', 'eventseat'),
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('eventseat_hero_subtitle', array(
        'label'   => __('Alt Başlık', 'eventseat'),
        'section' => 'eventseat_hero',
        'type'    => 'textarea',
    ));
}
add_action('customize_register', 'eventseat_customize_register');

/**
 * Widget areas
 */
function eventseat_widgets_init() {
    register_sidebar(array(
        'name'          => __('Sidebar', 'eventseat'),
        'id'            => 'sidebar-1',
        'description'   => __('Ana sidebar alanı', 'eventseat'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ));
    
    register_sidebar(array(
        'name'          => __('Footer', 'eventseat'),
        'id'            => 'footer-1',
        'description'   => __('Footer widget alanı', 'eventseat'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ));
}
add_action('widgets_init', 'eventseat_widgets_init');

/**
 * Custom post type for Events (optional)
 */
function eventseat_register_post_types() {
    $labels = array(
        'name'                  => _x('Etkinlikler', 'Post type general name', 'eventseat'),
        'singular_name'         => _x('Etkinlik', 'Post type singular name', 'eventseat'),
        'menu_name'             => _x('Etkinlikler', 'Admin Menu text', 'eventseat'),
        'add_new'               => __('Yeni Ekle', 'eventseat'),
        'add_new_item'          => __('Yeni Etkinlik Ekle', 'eventseat'),
        'edit_item'             => __('Etkinliği Düzenle', 'eventseat'),
        'new_item'              => __('Yeni Etkinlik', 'eventseat'),
        'view_item'             => __('Etkinliği Görüntüle', 'eventseat'),
        'search_items'          => __('Etkinlik Ara', 'eventseat'),
        'not_found'             => __('Etkinlik bulunamadı', 'eventseat'),
        'not_found_in_trash'    => __('Çöp kutusunda etkinlik bulunamadı', 'eventseat'),
    );
    
    $args = array(
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array('slug' => 'etkinlik'),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 5,
        'menu_icon'          => 'dashicons-calendar-alt',
        'supports'           => array('title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments'),
    );
    
    // Uncomment to enable custom post type
    // register_post_type('event', $args);
}
add_action('init', 'eventseat_register_post_types');

/**
 * Add custom body classes
 */
function eventseat_body_classes($classes) {
    if (is_home() || is_front_page()) {
        $classes[] = 'front-page';
    }
    if (is_singular()) {
        $classes[] = 'singular';
    }
    return $classes;
}
add_filter('body_class', 'eventseat_body_classes');

/**
 * Excerpt length
 */
function eventseat_excerpt_length($length) {
    return 20;
}
add_filter('excerpt_length', 'eventseat_excerpt_length', 999);

/**
 * Excerpt more
 */
function eventseat_excerpt_more($more) {
    return '...';
}
add_filter('excerpt_more', 'eventseat_excerpt_more');

/**
 * Elementor Support
 */
function eventseat_elementor_support() {
    // Add Elementor theme locations
    add_action('elementor/theme/register_locations', 'eventseat_register_elementor_locations');
    
    // Load Elementor widgets (only if file exists)
    $widgets_file = get_template_directory() . '/includes/elementor-widgets.php';
    if (file_exists($widgets_file)) {
        require_once $widgets_file;
    }
}
add_action('elementor/init', 'eventseat_elementor_support');

/**
 * Register Elementor Theme Locations
 */
function eventseat_register_elementor_locations($elementor_theme_manager) {
    $elementor_theme_manager->register_location(
        'header',
        [
            'label' => __('Header', 'eventseat'),
            'hook' => 'eventseat_header',
            'multiple' => false,
        ]
    );
    
    $elementor_theme_manager->register_location(
        'footer',
        [
            'label' => __('Footer', 'eventseat'),
            'hook' => 'eventseat_footer',
            'multiple' => false,
        ]
    );
    
    $elementor_theme_manager->register_location(
        'single',
        [
            'label' => __('Single', 'eventseat'),
            'hook' => 'eventseat_single',
            'multiple' => true,
        ]
    );
    
    $elementor_theme_manager->register_location(
        'archive',
        [
            'label' => __('Archive', 'eventseat'),
            'hook' => 'eventseat_archive',
            'multiple' => true,
        ]
    );
}

/**
 * Elementor Canvas Template - No Header/Footer
 */
function eventseat_add_elementor_canvas_template($post_templates) {
    $post_templates['elementor_canvas'] = __('Elementor Canvas (Tam Sayfa)', 'eventseat');
    return $post_templates;
}
add_filter('theme_page_templates', 'eventseat_add_elementor_canvas_template');
add_filter('theme_post_templates', 'eventseat_add_elementor_canvas_template');

/**
 * Elementor Full Width Template
 */
function eventseat_add_elementor_fullwidth_template($post_templates) {
    $post_templates['elementor_fullwidth'] = __('Elementor Geniş (Header + Footer)', 'eventseat');
    return $post_templates;
}
add_filter('theme_page_templates', 'eventseat_add_elementor_fullwidth_template');
add_filter('theme_post_templates', 'eventseat_add_elementor_fullwidth_template');

/**
 * Load custom page templates
 */
function eventseat_load_custom_templates($template) {
    $page_template = get_page_template_slug();
    
    if ($page_template === 'elementor_canvas') {
        return get_template_directory() . '/elementor-canvas.php';
    }
    
    if ($page_template === 'elementor_fullwidth') {
        return get_template_directory() . '/elementor-fullwidth.php';
    }
    
    return $template;
}
add_filter('template_include', 'eventseat_load_custom_templates');

/**
 * Add Elementor Page Settings support
 */
function eventseat_add_page_body_class($classes) {
    if (is_page()) {
        $classes[] = 'elementor-page';
    }
    return $classes;
}
add_filter('body_class', 'eventseat_add_page_body_class');

/**
 * Add Meta Boxes for Event Details (Classic Editor)
 */
function eventseat_add_event_meta_boxes() {
    add_meta_box(
        'eventseat_event_details',
        __('Etkinlik Detayları', 'eventseat'),
        'eventseat_event_details_callback',
        'post',
        'normal',
        'high'
    );
}
add_action('add_meta_boxes', 'eventseat_add_event_meta_boxes');

/**
 * Event Details Meta Box Callback
 */
function eventseat_event_details_callback($post) {
    // Nonce for security
    wp_nonce_field('eventseat_save_event_details', 'eventseat_event_details_nonce');
    
    // Get existing values
    $event_date = get_post_meta($post->ID, 'event_date', true);
    $event_time = get_post_meta($post->ID, 'event_time', true);
    $event_location = get_post_meta($post->ID, 'event_location', true);
    $event_venue = get_post_meta($post->ID, 'event_venue', true);
    $event_price = get_post_meta($post->ID, 'event_price', true);
    $event_price_currency = get_post_meta($post->ID, 'event_price_currency', true);
    ?>
    <table class="form-table">
        <tr>
            <th><label for="event_date"><?php _e('Tarih', 'eventseat'); ?></label></th>
            <td>
                <input type="date" id="event_date" name="event_date" value="<?php echo esc_attr($event_date); ?>" class="regular-text">
                <p class="description"><?php _e('Örnek: 2025-06-15', 'eventseat'); ?></p>
            </td>
        </tr>
        <tr>
            <th><label for="event_time"><?php _e('Saat', 'eventseat'); ?></label></th>
            <td>
                <input type="time" id="event_time" name="event_time" value="<?php echo esc_attr($event_time); ?>" class="regular-text">
                <p class="description"><?php _e('Örnek: 20:00', 'eventseat'); ?></p>
            </td>
        </tr>
        <tr>
            <th><label for="event_location"><?php _e('Şehir', 'eventseat'); ?></label></th>
            <td>
                <input type="text" id="event_location" name="event_location" value="<?php echo esc_attr($event_location); ?>" class="regular-text">
                <p class="description"><?php _e('Örnek: İstanbul', 'eventseat'); ?></p>
            </td>
        </tr>
        <tr>
            <th><label for="event_venue"><?php _e('Mekan', 'eventseat'); ?></label></th>
            <td>
                <input type="text" id="event_venue" name="event_venue" value="<?php echo esc_attr($event_venue); ?>" class="regular-text">
                <p class="description"><?php _e('Örnek: Volkswagen Arena', 'eventseat'); ?></p>
            </td>
        </tr>
        <tr>
            <th><label for="event_price"><?php _e('Fiyat', 'eventseat'); ?></label></th>
            <td>
                <input type="number" id="event_price" name="event_price" value="<?php echo esc_attr($event_price); ?>" class="regular-text" step="0.01">
            </td>
        </tr>
        <tr>
            <th><label for="event_price_currency"><?php _e('Para Birimi', 'eventseat'); ?></label></th>
            <td>
                <input type="text" id="event_price_currency" name="event_price_currency" value="<?php echo esc_attr($event_price_currency); ?>" class="regular-text">
                <p class="description"><?php _e('Örnek: TL, USD, EUR', 'eventseat'); ?></p>
            </td>
        </tr>
    </table>
    <?php
}

/**
 * Save Event Details Meta Box
 */
function eventseat_save_event_details($post_id) {
    // Check nonce
    if (!isset($_POST['eventseat_event_details_nonce']) || 
        !wp_verify_nonce($_POST['eventseat_event_details_nonce'], 'eventseat_save_event_details')) {
        return;
    }
    
    // Check autosave
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
        return;
    }
    
    // Check permissions
    if (!current_user_can('edit_post', $post_id)) {
        return;
    }
    
    // Save fields
    $fields = ['event_date', 'event_time', 'event_location', 'event_venue', 'event_price', 'event_price_currency'];
    
    foreach ($fields as $field) {
        if (isset($_POST[$field])) {
            update_post_meta($post_id, $field, sanitize_text_field($_POST[$field]));
        }
    }
}
add_action('save_post', 'eventseat_save_event_details');

/**
 * ACF Integration - Register Field Group if ACF is active
 */
function eventseat_acf_fields() {
    if (!function_exists('acf_add_local_field_group')) {
        return;
    }
    
    acf_add_local_field_group(array(
        'key' => 'group_eventseat_event',
        'title' => 'Etkinlik Detayları',
        'fields' => array(
            array(
                'key' => 'field_event_date',
                'label' => 'Tarih',
                'name' => 'event_date',
                'type' => 'date_picker',
                'display_format' => 'd/m/Y',
                'return_format' => 'Y-m-d',
                'first_day' => 1,
            ),
            array(
                'key' => 'field_event_time',
                'label' => 'Saat',
                'name' => 'event_time',
                'type' => 'time_picker',
                'display_format' => 'H:i',
                'return_format' => 'H:i',
            ),
            array(
                'key' => 'field_event_location',
                'label' => 'Şehir',
                'name' => 'event_location',
                'type' => 'text',
            ),
            array(
                'key' => 'field_event_venue',
                'label' => 'Mekan',
                'name' => 'event_venue',
                'type' => 'text',
            ),
            array(
                'key' => 'field_event_price',
                'label' => 'Fiyat',
                'name' => 'event_price',
                'type' => 'number',
                'step' => 0.01,
            ),
            array(
                'key' => 'field_event_price_currency',
                'label' => 'Para Birimi',
                'name' => 'event_price_currency',
                'type' => 'text',
                'default_value' => 'TL',
            ),
        ),
        'location' => array(
            array(
                array(
                    'param' => 'post_type',
                    'operator' => '==',
                    'value' => 'post',
                ),
            ),
        ),
        'menu_order' => 0,
        'position' => 'normal',
        'style' => 'default',
        'label_placement' => 'top',
        'instruction_placement' => 'label',
        'hide_on_screen' => '',
        'active' => true,
    ));
}
add_action('acf/init', 'eventseat_acf_fields');
