<?php
/**
 * Template Name: Elementor Geniş (Header + Footer)
 * Description: Elementor için geniş şablon - tema header ve footer ile
 *
 * @package EventSeat
 */

get_header();
?>

<main id="main-content" class="eventseat-elementor-fullwidth">
    <?php
    while (have_posts()) :
        the_post();
        the_content();
    endwhile;
    ?>
</main>

<?php
get_footer();
