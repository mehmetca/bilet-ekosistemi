<?php
/**
 * Event Search Widget
 *
 * @package EventSeat
 */

if (!defined('ABSPATH')) {
    exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

class EventSeat_Elementor_Event_Search_Widget extends Widget_Base {
    
    public function get_name() {
        return 'eventseat_event_search';
    }
    
    public function get_title() {
        return __('Etkinlik Arama', 'eventseat');
    }
    
    public function get_icon() {
        return 'eicon-search';
    }
    
    public function get_categories() {
        return ['eventseat', 'general'];
    }
    
    public function get_keywords() {
        return ['search', 'arama', 'event', 'etkinlik', 'ara'];
    }
    
    protected function register_controls() {
        // Content Section
        $this->start_controls_section(
            'content_section',
            [
                'label' => __('İçerik', 'eventseat'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        
        $this->add_control(
            'placeholder',
            [
                'label' => __('Placeholder Metni', 'eventseat'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Etkinlik ara...', 'eventseat'),
            ]
        );
        
        $this->add_control(
            'button_text',
            [
                'label' => __('Buton Metni', 'eventseat'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Ara', 'eventseat'),
            ]
        );
        
        $this->add_control(
            'show_button',
            [
                'label' => __('Buton Göster', 'eventseat'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'no',
            ]
        );
        
        $this->end_controls_section();
        
        // Style Section
        $this->start_controls_section(
            'style_section',
            [
                'label' => __('Stil', 'eventseat'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        
        $this->add_control(
            'input_background',
            [
                'label' => __('Input Arka Plan', 'eventseat'),
                'type' => Controls_Manager::COLOR,
                'default' => '#f1f5f9',
                'selectors' => [
                    '{{WRAPPER}} .eventseat-search-input' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_control(
            'input_focus_background',
            [
                'label' => __('Input Focus Arka Plan', 'eventseat'),
                'type' => Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .eventseat-search-input:focus' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_control(
            'input_focus_border',
            [
                'label' => __('Input Focus Border', 'eventseat'),
                'type' => Controls_Manager::COLOR,
                'default' => '#3b82f6',
                'selectors' => [
                    '{{WRAPPER}} .eventseat-search-input:focus' => 'box-shadow: 0 0 0 2px {{VALUE}};',
                ],
            ]
        );
        
        $this->add_control(
            'icon_color',
            [
                'label' => __('İkon Rengi', 'eventseat'),
                'type' => Controls_Manager::COLOR,
                'default' => '#94a3b8',
                'selectors' => [
                    '{{WRAPPER}} .eventseat-search-icon' => 'color: {{VALUE}};',
                ],
            ]
        );
        
        $this->end_controls_section();
    }
    
    protected function render() {
        $settings = $this->get_settings_for_display();
        ?>
        
        <form role="search" method="get" action="<?php echo esc_url(home_url('/')); ?>" class="eventseat-search-form">
            <div class="eventseat-search-wrapper">
                <svg class="eventseat-search-icon" xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <circle cx="11" cy="11" r="8"></circle>
                    <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                </svg>
                <input 
                    type="search" 
                    name="s" 
                    class="eventseat-search-input" 
                    placeholder="<?php echo esc_attr($settings['placeholder']); ?>"
                    value="<?php echo get_search_query(); ?>"
                >
                <?php if ($settings['show_button'] === 'yes') : ?>
                    <button type="submit" class="eventseat-search-button">
                        <?php echo esc_html($settings['button_text']); ?>
                    </button>
                <?php endif; ?>
            </div>
        </form>
        
        <?php
    }
}
