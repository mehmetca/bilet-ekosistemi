<?php
/**
 * Event Card Widget - Single Event
 *
 * @package EventSeat
 */

if (!defined('ABSPATH')) {
    exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

class EventSeat_Elementor_Event_Card_Widget extends Widget_Base {
    
    public function get_name() {
        return 'eventseat_event_card';
    }
    
    public function get_title() {
        return __('Etkinlik Kartı', 'eventseat');
    }
    
    public function get_icon() {
        return 'eicon-single-post';
    }
    
    public function get_categories() {
        return ['eventseat', 'general'];
    }
    
    public function get_keywords() {
        return ['event', 'etkinlik', 'card', 'single', 'kart'];
    }
    
    protected function register_controls() {
        // Content Section
        $this->start_controls_section(
            'content_section',
            [
                'label' => __('İçerik', 'eventseat'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        
        $this->add_control(
            'event_id',
            [
                'label' => __('Etkinlik ID', 'eventseat'),
                'type' => Controls_Manager::NUMBER,
                'description' => __('Boş bırakırsanız son etkinlik gösterilir', 'eventseat'),
            ]
        );
        
        $this->add_control(
            'show_image',
            [
                'label' => __('Görsel Göster', 'eventseat'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
            ]
        );
        
        $this->add_control(
            'show_excerpt',
            [
                'label' => __('Özet Göster', 'eventseat'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
            ]
        );
        
        $this->add_control(
            'excerpt_length',
            [
                'label' => __('Özet Uzunluğu', 'eventseat'),
                'type' => Controls_Manager::NUMBER,
                'default' => 20,
                'min' => 10,
                'max' => 100,
                'condition' => [
                    'show_excerpt' => 'yes',
                ],
            ]
        );
        
        $this->end_controls_section();
        
        // Style Section
        $this->start_controls_section(
            'style_section',
            [
                'label' => __('Stil', 'eventseat'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        
        $this->add_control(
            'card_background',
            [
                'label' => __('Kart Arka Plan', 'eventseat'),
                'type' => Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .eventseat-card' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_control(
            'title_color',
            [
                'label' => __('Başlık Rengi', 'eventseat'),
                'type' => Controls_Manager::COLOR,
                'default' => '#0f172a',
                'selectors' => [
                    '{{WRAPPER}} .eventseat-card-title' => 'color: {{VALUE}};',
                ],
            ]
        );
        
        $this->end_controls_section();
    }
    
    protected function render() {
        $settings = $this->get_settings_for_display();
        
        $event_id = $settings['event_id'];
        
        if (empty($event_id)) {
            // Get latest post
            $latest = get_posts(['posts_per_page' => 1]);
            if (empty($latest)) {
                echo '<p>' . __('Etkinlik bulunamadı.', 'eventseat') . '</p>';
                return;
            }
            $event_id = $latest[0]->ID;
        }
        
        $event = get_post($event_id);
        
        if (!$event || $event->post_status !== 'publish') {
            echo '<p>' . __('Etkinlik bulunamadı.', 'eventseat') . '</p>';
            return;
        }
        
        $date = get_post_meta($event_id, 'event_date', true);
        $time = get_post_meta($event_id, 'event_time', true);
        $location = get_post_meta($event_id, 'event_location', true);
        $venue = get_post_meta($event_id, 'event_venue', true);
        $price = get_post_meta($event_id, 'event_price', true);
        ?>
        
        <article class="eventseat-card">
            <?php if ($settings['show_image'] === 'yes' && has_post_thumbnail($event_id)) : ?>
                <div class="eventseat-card-image">
                    <a href="<?php echo get_permalink($event_id); ?>">
                        <?php echo get_the_post_thumbnail($event_id, 'event-card'); ?>
                    </a>
                </div>
            <?php endif; ?>
            
            <div class="eventseat-card-content">
                <h3 class="eventseat-card-title">
                    <a href="<?php echo get_permalink($event_id); ?>"><?php echo esc_html($event->post_title); ?></a>
                </h3>
                
                <?php if ($date) : ?>
                    <div class="eventseat-card-meta">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
                        <span><?php echo esc_html($date); ?><?php if ($time) echo ' • ' . esc_html($time); ?></span>
                    </div>
                <?php endif; ?>
                
                <?php if ($venue || $location) : ?>
                    <div class="eventseat-card-meta">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
                        <span><?php echo esc_html($venue ? $venue . ', ' . $location : $location); ?></span>
                    </div>
                <?php endif; ?>
                
                <?php if ($settings['show_excerpt'] === 'yes') : ?>
                    <p class="eventseat-card-excerpt">
                        <?php echo wp_trim_words($event->post_content, $settings['excerpt_length'], '...'); ?>
                    </p>
                <?php endif; ?>
                
                <div class="eventseat-card-footer">
                    <?php if ($price) : ?>
                        <span class="eventseat-card-price"><?php echo esc_html($price); ?></span>
                    <?php endif; ?>
                    <a href="<?php echo get_permalink($event_id); ?>" class="eventseat-card-button">
                        <?php _e('Satın Al', 'eventseat'); ?>
                    </a>
                </div>
            </div>
        </article>
        
        <?php
    }
}
