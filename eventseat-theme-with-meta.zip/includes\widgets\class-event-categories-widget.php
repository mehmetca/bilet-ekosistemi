<?php
/**
 * Event Categories Widget
 *
 * @package EventSeat
 */

if (!defined('ABSPATH')) {
    exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

class EventSeat_Elementor_Event_Categories_Widget extends Widget_Base {
    
    public function get_name() {
        return 'eventseat_event_categories';
    }
    
    public function get_title() {
        return __('Etkinlik Kategorileri', 'eventseat');
    }
    
    public function get_icon() {
        return 'eicon-taxonomy';
    }
    
    public function get_categories() {
        return ['eventseat', 'general'];
    }
    
    public function get_keywords() {
        return ['category', 'kategori', 'etkinlik', 'event', 'filter', 'filtre'];
    }
    
    protected function register_controls() {
        // Content Section
        $this->start_controls_section(
            'content_section',
            [
                'label' => __('İçerik', 'eventseat'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        
        $this->add_control(
            'title',
            [
                'label' => __('Başlık', 'eventseat'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Kategoriler', 'eventseat'),
            ]
        );
        
        $this->add_control(
            'show_count',
            [
                'label' => __('Sayı Göster', 'eventseat'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
            ]
        );
        
        $this->add_control(
            'style',
            [
                'label' => __('Stil', 'eventseat'),
                'type' => Controls_Manager::SELECT,
                'default' => 'buttons',
                'options' => [
                    'buttons' => __('Butonlar', 'eventseat'),
                    'list' => __('Liste', 'eventseat'),
                    'pills' => __('Pills', 'eventseat'),
                ],
            ]
        );
        
        $this->end_controls_section();
        
        // Style Section
        $this->start_controls_section(
            'style_section',
            [
                'label' => __('Stil', 'eventseat'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        
        $this->add_control(
            'button_background',
            [
                'label' => __('Buton Arka Plan', 'eventseat'),
                'type' => Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .eventseat-category-btn' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_control(
            'button_border',
            [
                'label' => __('Buton Border', 'eventseat'),
                'type' => Controls_Manager::COLOR,
                'default' => '#cbd5e1',
                'selectors' => [
                    '{{WRAPPER}} .eventseat-category-btn' => 'border-color: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_control(
            'button_text',
            [
                'label' => __('Buton Metin', 'eventseat'),
                'type' => Controls_Manager::COLOR,
                'default' => '#334155',
                'selectors' => [
                    '{{WRAPPER}} .eventseat-category-btn' => 'color: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_control(
            'active_background',
            [
                'label' => __('Aktif Arka Plan', 'eventseat'),
                'type' => Controls_Manager::COLOR,
                'default' => '#2563eb',
                'selectors' => [
                    '{{WRAPPER}} .eventseat-category-btn.active' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}} .eventseat-category-btn:hover' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_control(
            'active_text',
            [
                'label' => __('Aktif Metin', 'eventseat'),
                'type' => Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .eventseat-category-btn.active' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .eventseat-category-btn:hover' => 'color: {{VALUE}};',
                ],
            ]
        );
        
        $this->end_controls_section();
    }
    
    protected function render() {
        $settings = $this->get_settings_for_display();
        
        $categories = get_categories([
            'orderby' => 'name',
            'order' => 'ASC',
            'hide_empty' => true,
        ]);
        
        if (empty($categories)) {
            echo '<p>' . __('Kategori bulunamadı.', 'eventseat') . '</p>';
            return;
        }
        
        $current_cat = get_query_var('cat');
        $style = $settings['style'];
        $wrapper_class = 'eventseat-categories-' . $style;
        ?>
        
        <div class="eventseat-categories-wrapper">
            <?php if (!empty($settings['title'])) : ?>
                <h4 class="eventseat-categories-title"><?php echo esc_html($settings['title']); ?></h4>
            <?php endif; ?>
            
            <div class="eventseat-categories <?php echo esc_attr($wrapper_class); ?>">
                <?php foreach ($categories as $category) : 
                    $is_active = $current_cat == $category->term_id;
                    $count = $settings['show_count'] === 'yes' ? ' (' . $category->count . ')' : '';
                    ?>
                    <a 
                        href="<?php echo esc_url(get_category_link($category->term_id)); ?>" 
                        class="eventseat-category-btn <?php echo $is_active ? 'active' : ''; ?>"
                    >
                        <?php echo esc_html($category->name) . esc_html($count); ?>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>
        
        <?php
    }
}
