<?php
/**
 * Single post template
 *
 * @package EventSeat
 */

get_header();

while (have_posts()) :
    the_post();
    ?>
    
    <!-- Event Header -->
    <header class="single-header">
        <div class="container">
            <?php eventseat_category_badge(); ?>
            <h1 class="single-title"><?php the_title(); ?></h1>
            
            <div class="single-meta">
                <?php
                $date = get_post_meta(get_the_ID(), 'event_date', true);
                $time = get_post_meta(get_the_ID(), 'event_time', true);
                $location = get_post_meta(get_the_ID(), 'event_location', true);
                $venue = get_post_meta(get_the_ID(), 'event_venue', true);
                ?>
                
                <?php if ($date) : ?>
                    <span>
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align: middle; margin-right: 0.25rem;"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
                        <?php echo esc_html($date); ?><?php if ($time) echo ' • ' . esc_html($time); ?>
                    </span>
                <?php endif; ?>
                
                <?php if ($venue || $location) : ?>
                    <span>
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align: middle; margin-right: 0.25rem;"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
                        <?php echo esc_html($venue ? $venue . ', ' . $location : $location); ?>
                    </span>
                <?php endif; ?>
            </div>
        </div>
    </header>
    
    <!-- Event Content -->
    <article class="single-content">
        <div class="container">
            <?php if (has_post_thumbnail()) : ?>
                <div style="margin-bottom: 2rem; border-radius: 0.75rem; overflow: hidden;">
                    <?php the_post_thumbnail('large', array('style' => 'width: 100%; height: auto;')); ?>
                </div>
            <?php endif; ?>
            
            <div class="entry-content">
                <?php the_content(); ?>
            </div>
            
            <!-- Buy Ticket Box -->
            <?php
            $price = get_post_meta(get_the_ID(), 'event_price', true);
            $buy_url = get_post_meta(get_the_ID(), 'event_buy_url', true);
            ?>
            <div style="margin-top: 3rem; padding: 1.5rem; background-color: var(--primary-50); border-radius: 0.75rem; border: 1px solid var(--primary-200);">
                <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 1rem;">
                    <div>
                        <h3 style="font-size: 1.25rem; font-weight: 600; margin-bottom: 0.5rem;"><?php _e('Bilet Satın Al', 'eventseat'); ?></h3>
                        <?php if ($price) : ?>
                            <p style="font-size: 1.5rem; font-weight: 700; color: var(--primary-600);"><?php echo esc_html($price); ?></p>
                        <?php endif; ?>
                    </div>
                    <a href="<?php echo $buy_url ? esc_url($buy_url) : '#'; ?>" class="btn btn-primary btn-lg">
                        <?php _e('Satın Al', 'eventseat'); ?>
                    </a>
                </div>
            </div>
            
            <!-- Post Navigation -->
            <nav class="post-navigation">
                <?php
                previous_post_link(
                    '<div class="nav-previous">%link</div>',
                    '<span style="display: block; font-size: 0.875rem; color: var(--slate-500); margin-bottom: 0.25rem;">' . __('Önceki Etkinlik', 'eventseat') . '</span><span style="font-weight: 500; color: var(--slate-900);">%title</span>'
                );
                next_post_link(
                    '<div class="nav-next" style="text-align: right;">%link</div>',
                    '<span style="display: block; font-size: 0.875rem; color: var(--slate-500); margin-bottom: 0.25rem;">' . __('Sonraki Etkinlik', 'eventseat') . '</span><span style="font-weight: 500; color: var(--slate-900);">%title</span>'
                );
                ?>
            </nav>
            
            <!-- Comments -->
            <?php
            if (comments_open() || get_comments_number()) :
                comments_template();
            endif;
            ?>
        </div>
    </article>
    
<?php
endwhile;

get_footer();
