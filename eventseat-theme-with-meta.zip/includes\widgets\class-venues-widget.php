<?php
/**
 * Venues Widget (Mekanlar)
 *
 * @package EventSeat
 */

if (!defined('ABSPATH')) {
    exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

class EventSeat_Elementor_Venues_Widget extends Widget_Base {
    
    public function get_name() {
        return 'eventseat_venues';
    }
    
    public function get_title() {
        return __('Mekanlar', 'eventseat');
    }
    
    public function get_icon() {
        return 'eicon-map-pin';
    }
    
    public function get_categories() {
        return ['eventseat', 'general'];
    }
    
    public function get_keywords() {
        return ['venue', 'mekan', 'location', 'yer', 'sahne', 'salon'];
    }
    
    protected function register_controls() {
        // Content Section
        $this->start_controls_section(
            'content_section',
            [
                'label' => __('İçerik', 'eventseat'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        
        $this->add_control(
            'title',
            [
                'label' => __('Başlık', 'eventseat'),
                'type' => Controls_Manager::TEXT,
                'default' => __('Mekanlar', 'eventseat'),
            ]
        );
        
        $this->add_control(
            'venue_meta_key',
            [
                'label' => __('Mekan Meta Anahtarı', 'eventseat'),
                'type' => Controls_Manager::TEXT,
                'default' => 'event_venue',
                'description' => __('Mekan adının saklandığı özel alan anahtarı', 'eventseat'),
            ]
        );
        
        $this->add_control(
            'max_venues',
            [
                'label' => __('Maksimum Mekan', 'eventseat'),
                'type' => Controls_Manager::NUMBER,
                'default' => 12,
                'min' => 1,
                'max' => 50,
            ]
        );
        
        $this->add_control(
            'columns',
            [
                'label' => __('Kolon Sayısı', 'eventseat'),
                'type' => Controls_Manager::SELECT,
                'default' => '3',
                'options' => [
                    '2' => '2',
                    '3' => '3',
                    '4' => '4',
                ],
            ]
        );
        
        $this->add_control(
            'show_event_count',
            [
                'label' => __('Etkinlik Sayısı Göster', 'eventseat'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
            ]
        );
        
        $this->add_control(
            'show_city',
            [
                'label' => __('Şehir Göster', 'eventseat'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
            ]
        );
        
        $this->add_control(
            'city_meta_key',
            [
                'label' => __('Şehir Meta Anahtarı', 'eventseat'),
                'type' => Controls_Manager::TEXT,
                'default' => 'event_location',
                'condition' => [
                    'show_city' => 'yes',
                ],
            ]
        );
        
        $this->end_controls_section();
        
        // Style Section
        $this->start_controls_section(
            'style_section',
            [
                'label' => __('Stil', 'eventseat'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        
        $this->add_control(
            'card_bg',
            [
                'label' => __('Kart Arka Plan', 'eventseat'),
                'type' => Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .eventseat-venue-card' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_control(
            'card_border',
            [
                'label' => __('Kart Border', 'eventseat'),
                'type' => Controls_Manager::COLOR,
                'default' => '#e2e8f0',
                'selectors' => [
                    '{{WRAPPER}} .eventseat-venue-card' => 'border-color: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_control(
            'name_color',
            [
                'label' => __('Mekan Adı Rengi', 'eventseat'),
                'type' => Controls_Manager::COLOR,
                'default' => '#0f172a',
                'selectors' => [
                    '{{WRAPPER}} .eventseat-venue-name' => 'color: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_control(
            'city_color',
            [
                'label' => __('Şehir Rengi', 'eventseat'),
                'type' => Controls_Manager::COLOR,
                'default' => '#2563eb',
                'selectors' => [
                    '{{WRAPPER}} .eventseat-venue-city' => 'color: {{VALUE}};',
                ],
            ]
        );
        
        $this->end_controls_section();
    }
    
    protected function render() {
        $settings = $this->get_settings_for_display();
        
        // Get all posts with venue meta
        $args = [
            'posts_per_page' => -1,
            'post_type' => 'post',
            'post_status' => 'publish',
            'meta_key' => $settings['venue_meta_key'],
            'meta_query' => [
                [
                    'key' => $settings['venue_meta_key'],
                    'value' => '',
                    'compare' => '!=',
                ],
            ],
        ];
        
        $query = new WP_Query($args);
        
        if (!$query->have_posts()) {
            echo '<p>' . __('Mekan bulunamadı.', 'eventseat') . '</p>';
            return;
        }
        
        // Collect unique venues
        $venues = [];
        
        while ($query->have_posts()) {
            $query->the_post();
            $venue_name = get_post_meta(get_the_ID(), $settings['venue_meta_key'], true);
            $city = $settings['show_city'] === 'yes' 
                ? get_post_meta(get_the_ID(), $settings['city_meta_key'], true) 
                : '';
            
            if (empty($venue_name)) continue;
            
            $venue_key = sanitize_title($venue_name);
            
            if (!isset($venues[$venue_key])) {
                $venues[$venue_key] = [
                    'name' => $venue_name,
                    'city' => $city,
                    'event_count' => 0,
                    'thumbnail' => get_the_post_thumbnail_url(get_the_ID(), 'medium'),
                ];
            }
            
            $venues[$venue_key]['event_count']++;
            
            // Use first found thumbnail if venue doesn't have one
            if (empty($venues[$venue_key]['thumbnail']) && has_post_thumbnail()) {
                $venues[$venue_key]['thumbnail'] = get_the_post_thumbnail_url(get_the_ID(), 'medium');
            }
        }
        
        wp_reset_postdata();
        
        // Limit venues
        $venues = array_slice($venues, 0, $settings['max_venues'], true);
        
        // Sort by event count (descending)
        uasort($venues, function($a, $b) {
            return $b['event_count'] - $a['event_count'];
        });
        ?>
        
        <div class="eventseat-venues-wrapper">
            <?php if (!empty($settings['title'])) : ?>
                <h3 class="eventseat-venues-title"><?php echo esc_html($settings['title']); ?></h3>
            <?php endif; ?>
            
            <div class="eventseat-venues-grid eventseat-grid-<?php echo esc_attr($settings['columns']); ?>">
                <?php foreach ($venues as $venue) : ?>
                    <div class="eventseat-venue-card">
                        <div class="eventseat-venue-content">
                            <h4 class="eventseat-venue-name"><?php echo esc_html($venue['name']); ?></h4>
                            
                            <?php if ($settings['show_city'] === 'yes' && $venue['city']) : ?>
                                <div class="eventseat-venue-city">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="vertical-align: middle; margin-right: 0.25rem;"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
                                    <?php echo esc_html($venue['city']); ?>
                                </div>
                            <?php endif; ?>
                            
                            <?php if ($settings['show_event_count'] === 'yes') : ?>
                                <div class="eventseat-venue-count">
                                    <?php 
                                    printf(
                                        _n('%d etkinlik', '%d etkinlik', $venue['event_count'], 'eventseat'),
                                        $venue['event_count']
                                    ); 
                                    ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
        
        <?php
    }
}
