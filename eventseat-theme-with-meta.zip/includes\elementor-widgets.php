<?php
/**
 * EventSeat Elementor Widgets
 *
 * @package EventSeat
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Register EventSeat Elementor Widgets
 */
function eventseat_register_elementor_widgets($widgets_manager) {
    // Widget file paths
    $widgets = [
        'event-list' => __DIR__ . '/widgets/class-event-list-widget.php',
        'event-card' => __DIR__ . '/widgets/class-event-card-widget.php',
        'event-search' => __DIR__ . '/widgets/class-event-search-widget.php',
        'event-categories' => __DIR__ . '/widgets/class-event-categories-widget.php',
        'event-calendar' => __DIR__ . '/widgets/class-event-calendar-widget.php',
        'artists' => __DIR__ . '/widgets/class-artists-widget.php',
        'venues' => __DIR__ . '/widgets/class-venues-widget.php',
    ];
    
    // Widget class mappings
    $widget_classes = [
        'event-list' => 'EventSeat_Elementor_Event_List_Widget',
        'event-card' => 'EventSeat_Elementor_Event_Card_Widget',
        'event-search' => 'EventSeat_Elementor_Event_Search_Widget',
        'event-categories' => 'EventSeat_Elementor_Event_Categories_Widget',
        'event-calendar' => 'EventSeat_Elementor_Event_Calendar_Widget',
        'artists' => 'EventSeat_Elementor_Artists_Widget',
        'venues' => 'EventSeat_Elementor_Venues_Widget',
    ];
    
    foreach ($widgets as $key => $file) {
        if (file_exists($file)) {
            require_once $file;
            
            $class_name = $widget_classes[$key];
            if (class_exists($class_name)) {
                $widgets_manager->register(new $class_name());
            }
        }
    }
}
add_action('elementor/widgets/register', 'eventseat_register_elementor_widgets', 10);

/**
 * Add EventSeat widget category
 */
function eventseat_add_elementor_widget_category($elements_manager) {
    $elements_manager->add_category(
        'eventseat',
        [
            'title' => __('EventSeat', 'eventseat'),
            'icon' => 'eicon-calendar',
        ]
    );
}
add_action('elementor/elements/categories_registered', 'eventseat_add_elementor_widget_category', 10);
