<?php
/**
 * Event List Widget
 *
 * @package EventSeat
 */

if (!defined('ABSPATH')) {
    exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

class EventSeat_Elementor_Event_List_Widget extends Widget_Base {
    
    public function get_name() {
        return 'eventseat_event_list';
    }
    
    public function get_title() {
        return __('Etkinlik Listesi', 'eventseat');
    }
    
    public function get_icon() {
        return 'eicon-post-list';
    }
    
    public function get_categories() {
        return ['eventseat', 'general'];
    }
    
    public function get_keywords() {
        return ['event', 'etkinlik', 'list', 'liste', 'events'];
    }
    
    protected function register_controls() {
        // Content Section
        $this->start_controls_section(
            'content_section',
            [
                'label' => __('İçerik', 'eventseat'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        
        $this->add_control(
            'posts_per_page',
            [
                'label' => __('Etkinlik Sayısı', 'eventseat'),
                'type' => Controls_Manager::NUMBER,
                'default' => 6,
                'min' => 1,
                'max' => 24,
                'step' => 1,
            ]
        );
        
        $this->add_control(
            'category',
            [
                'label' => __('Kategori', 'eventseat'),
                'type' => Controls_Manager::SELECT,
                'default' => '',
                'options' => $this->get_categories_options(),
            ]
        );
        
        $this->add_control(
            'columns',
            [
                'label' => __('Kolon Sayısı', 'eventseat'),
                'type' => Controls_Manager::SELECT,
                'default' => '3',
                'options' => [
                    '1' => '1',
                    '2' => '2',
                    '3' => '3',
                    '4' => '4',
                ],
            ]
        );
        
        $this->add_control(
            'show_image',
            [
                'label' => __('Görsel Göster', 'eventseat'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
            ]
        );
        
        $this->add_control(
            'show_date',
            [
                'label' => __('Tarih Göster', 'eventseat'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
            ]
        );
        
        $this->add_control(
            'show_location',
            [
                'label' => __('Yer Göster', 'eventseat'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
            ]
        );
        
        $this->add_control(
            'show_price',
            [
                'label' => __('Fiyat Göster', 'eventseat'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
            ]
        );
        
        $this->add_control(
            'show_button',
            [
                'label' => __('Buton Göster', 'eventseat'),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
            ]
        );
        
        $this->end_controls_section();
        
        // Style Section
        $this->start_controls_section(
            'style_section',
            [
                'label' => __('Stil', 'eventseat'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );
        
        $this->add_control(
            'card_background',
            [
                'label' => __('Kart Arka Plan', 'eventseat'),
                'type' => Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .eventseat-card' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_control(
            'card_border',
            [
                'label' => __('Kart Border', 'eventseat'),
                'type' => Controls_Manager::COLOR,
                'default' => '#e2e8f0',
                'selectors' => [
                    '{{WRAPPER}} .eventseat-card' => 'border-color: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_control(
            'title_color',
            [
                'label' => __('Başlık Rengi', 'eventseat'),
                'type' => Controls_Manager::COLOR,
                'default' => '#0f172a',
                'selectors' => [
                    '{{WRAPPER}} .eventseat-card-title' => 'color: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_control(
            'price_color',
            [
                'label' => __('Fiyat Rengi', 'eventseat'),
                'type' => Controls_Manager::COLOR,
                'default' => '#2563eb',
                'selectors' => [
                    '{{WRAPPER}} .eventseat-card-price' => 'color: {{VALUE}};',
                ],
            ]
        );
        
        $this->add_control(
            'button_background',
            [
                'label' => __('Buton Arka Plan', 'eventseat'),
                'type' => Controls_Manager::COLOR,
                'default' => '#2563eb',
                'selectors' => [
                    '{{WRAPPER}} .eventseat-card-button' => 'background-color: {{VALUE}};',
                ],
            ]
        );
        
        $this->end_controls_section();
    }
    
    protected function get_categories_options() {
        $options = ['' => __('Tümü', 'eventseat')];
        $categories = get_categories();
        foreach ($categories as $category) {
            $options[$category->term_id] = $category->name;
        }
        return $options;
    }
    
    protected function render() {
        $settings = $this->get_settings_for_display();
        
        $args = [
            'posts_per_page' => $settings['posts_per_page'],
            'post_type' => 'post',
            'post_status' => 'publish',
        ];
        
        if (!empty($settings['category'])) {
            $args['cat'] = $settings['category'];
        }
        
        $query = new WP_Query($args);
        
        if (!$query->have_posts()) {
            echo '<p>' . __('Etkinlik bulunamadı.', 'eventseat') . '</p>';
            return;
        }
        
        $columns = $settings['columns'];
        $grid_class = 'eventseat-grid-' . $columns;
        ?>
        
        <div class="eventseat-events-grid <?php echo esc_attr($grid_class); ?>">
            <?php
            while ($query->have_posts()) :
                $query->the_post();
                $date = get_post_meta(get_the_ID(), 'event_date', true);
                $time = get_post_meta(get_the_ID(), 'event_time', true);
                $location = get_post_meta(get_the_ID(), 'event_location', true);
                $venue = get_post_meta(get_the_ID(), 'event_venue', true);
                $price = get_post_meta(get_the_ID(), 'event_price', true);
                ?>
                
                <article class="eventseat-card">
                    <?php if ($settings['show_image'] === 'yes' && has_post_thumbnail()) : ?>
                        <div class="eventseat-card-image">
                            <a href="<?php the_permalink(); ?>">
                                <?php the_post_thumbnail('event-card'); ?>
                            </a>
                        </div>
                    <?php endif; ?>
                    
                    <div class="eventseat-card-content">
                        <h3 class="eventseat-card-title">
                            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                        </h3>
                        
                        <?php if ($settings['show_date'] === 'yes' && $date) : ?>
                            <div class="eventseat-card-meta">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
                                <span><?php echo esc_html($date); ?><?php if ($time) echo ' • ' . esc_html($time); ?></span>
                            </div>
                        <?php endif; ?>
                        
                        <?php if ($settings['show_location'] === 'yes' && ($venue || $location)) : ?>
                            <div class="eventseat-card-meta">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
                                <span><?php echo esc_html($venue ? $venue . ', ' . $location : $location); ?></span>
                            </div>
                        <?php endif; ?>
                        
                        <div class="eventseat-card-footer">
                            <?php if ($settings['show_price'] === 'yes' && $price) : ?>
                                <span class="eventseat-card-price"><?php echo esc_html($price); ?></span>
                            <?php endif; ?>
                            
                            <?php if ($settings['show_button'] === 'yes') : ?>
                                <a href="<?php the_permalink(); ?>" class="eventseat-card-button">
                                    <?php _e('Satın Al', 'eventseat'); ?>
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </article>
                
            <?php endwhile; ?>
        </div>
        
        <?php
        wp_reset_postdata();
    }
}
