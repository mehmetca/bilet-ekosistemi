<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <?php wp_head(); ?>
</head>
<body <?php body_class('bg-slate-50'); ?>>
<?php wp_body_open(); ?>

<header class="site-header">
    <div class="container">
        <div class="header-inner">
            <!-- Logo -->
            <div class="site-branding">
                <a href="<?php echo esc_url(home_url('/')); ?>" class="site-logo">
                    <?php 
                    $logo_text = get_theme_mod('eventseat_logo_text', 'EventSeat');
                    $logo_parts = explode('Seat', $logo_text);
                    if (count($logo_parts) > 1) {
                        echo esc_html($logo_parts[0]) . '<span>Seat</span>';
                    } else {
                        echo esc_html($logo_text);
                    }
                    ?>
                </a>
            </div>
            
            <!-- Navigation -->
            <nav class="main-navigation">
                <?php
                wp_nav_menu(array(
                    'theme_location' => 'primary',
                    'menu_class'     => 'nav-menu',
                    'container'      => false,
                    'fallback_cb'    => false,
                ));
                ?>
            </nav>
            
            <!-- Header Actions -->
            <div class="header-actions">
                <?php if (is_user_logged_in()) : ?>
                    <a href="<?php echo esc_url(wp_logout_url(home_url())); ?>" class="btn btn-ghost">
                        <?php _e('Çıkış', 'eventseat'); ?>
                    </a>
                <?php else : ?>
                    <a href="<?php echo esc_url(wp_login_url()); ?>" class="btn btn-ghost">
                        <?php _e('Giriş', 'eventseat'); ?>
                    </a>
                    <a href="<?php echo esc_url(wp_registration_url()); ?>" class="btn btn-primary">
                        <?php _e('Üye Ol', 'eventseat'); ?>
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</header>

<main id="main-content">
